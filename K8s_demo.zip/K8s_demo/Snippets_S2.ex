Snippets:
env:
  - name: WELCOME_MESSAGE
    valueFrom:
      configMapKeyRef:
        name: demo-config
        key: welcomeMessage
  - name: PASSWORD
    valueFrom:
      secretKeyRef:
        name: demo-secret
        key: password